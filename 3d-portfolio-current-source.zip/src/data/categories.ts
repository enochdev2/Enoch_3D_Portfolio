export const categories = [
  "All",
  "Character",
  "Product Visualization",
  "Hard Surface",
  "Simulation",
] as const;

export type Category = (typeof categories)[number];
