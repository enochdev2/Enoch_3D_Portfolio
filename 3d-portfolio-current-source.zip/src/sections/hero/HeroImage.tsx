import {
  motion,
  useMotionValue,
  useReducedMotion,
  useSpring,
} from "framer-motion";
import character from "../../assets/hero/character.png";

export default function HeroImage() {
  const shouldReduceMotion = useReducedMotion();
  const pointerX = useMotionValue(0);
  const pointerY = useMotionValue(0);
  const rotateX = useSpring(pointerY, {
    stiffness: 130,
    damping: 20,
    mass: 0.7,
  });
  const rotateY = useSpring(pointerX, {
    stiffness: 130,
    damping: 20,
    mass: 0.7,
  });

  function handlePointerMove(event: React.PointerEvent<HTMLDivElement>) {
    if (shouldReduceMotion || event.pointerType === "touch") return;

    const bounds = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width - 0.5;
    const y = (event.clientY - bounds.top) / bounds.height - 0.5;

    pointerX.set(x * 14);
    pointerY.set(y * -12);
  }

  function resetPointer() {
    pointerX.set(0);
    pointerY.set(0);
  }

  return (
    <div
      className="relative mx-auto w-full max-w-[570px] [perspective:1400px]"
      onPointerMove={handlePointerMove}
      onPointerLeave={resetPointer}
    >
      <div className="pointer-events-none absolute inset-[12%] rounded-full bg-orange-500/20 blur-[100px]" />
      <div className="pointer-events-none absolute -right-3 top-12 h-40 w-40 rounded-full border border-orange-300/15 [transform:rotateX(68deg)_rotateZ(-24deg)]" />
      <div className="pointer-events-none absolute -bottom-5 left-6 h-52 w-52 rounded-full border border-white/10 [transform:rotateX(72deg)_rotateZ(18deg)]" />

      <motion.div
        style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
        className="relative rounded-[2.5rem] border border-white/10 bg-gradient-to-br from-white/[0.11] via-white/[0.035] to-orange-500/[0.06] p-4 shadow-[0_35px_100px_rgba(0,0,0,0.45)] backdrop-blur-sm sm:p-6"
      >
        <div className="pointer-events-none absolute inset-3 rounded-[2rem] border border-white/[0.07]" />

        <div
          className="pointer-events-none absolute left-8 top-8 z-20 rounded-full border border-white/10 bg-zinc-950/65 px-4 py-2 text-[10px] font-semibold uppercase tracking-[0.24em] text-zinc-300 backdrop-blur-md"
          style={{ transform: "translateZ(45px)" }}
        >
          Blender · 3D artwork
        </div>

        <motion.img
          src={character}
          alt="Stylized 3D character artwork by Enoch Promise"
          className="relative z-10 mx-auto w-full object-contain drop-shadow-[0_30px_35px_rgba(0,0,0,0.35)]"
          style={{ z: 70 }}
          animate={
            shouldReduceMotion
              ? undefined
              : { y: [0, -12, 0], rotateZ: [-0.5, 0.5, -0.5] }
          }
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        <div
          className="absolute bottom-7 right-7 z-20 rounded-2xl border border-white/10 bg-zinc-950/75 px-4 py-3 shadow-xl backdrop-blur-md"
          style={{ transform: "translateZ(55px)" }}
        >
          <p className="text-[10px] uppercase tracking-[0.2em] text-zinc-500">
            Creative focus
          </p>
          <p className="mt-1 text-sm font-semibold text-white">
            Form · Light · Motion
          </p>
        </div>
      </motion.div>

      <p className="mt-5 text-center text-xs tracking-wide text-zinc-500">
        Move your cursor over the artwork to explore its depth
      </p>
    </div>
  );
}
