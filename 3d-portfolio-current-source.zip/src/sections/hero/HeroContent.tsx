import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { motion, useReducedMotion } from "framer-motion";
import { hero } from "../../data/hero";

export default function HeroContent() {
  const shouldReduceMotion = useReducedMotion();

  return (
    <motion.div
      initial={shouldReduceMotion ? false : { opacity: 0, y: 28 }}
      animate={shouldReduceMotion ? undefined : { opacity: 1, y: 0 }}
      transition={{ duration: 0.75, ease: [0.22, 0.61, 0.36, 1] }}
      className="relative z-10 max-w-2xl"
    >
      <p className="mb-5 flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.32em] text-orange-400">
        <span className="h-px w-8 bg-orange-400" />
        3D ARTIST / ANIMATOR
      </p>

      <h1 className="mb-5 font-['Space_Grotesk'] text-5xl font-bold leading-[1.02] tracking-tight sm:text-6xl lg:text-7xl">
        {hero.name.split(" ")[0]}
        <span className="block bg-gradient-to-r from-white via-zinc-200 to-zinc-500 bg-clip-text text-transparent">
          {hero.name.split(" ").slice(1).join(" ")}
        </span>
      </h1>

      <h2 className="mb-5 text-xl font-medium text-zinc-200 sm:text-2xl">
        {hero.title}
      </h2>

      <p className="mb-8 max-w-xl text-base leading-8 text-zinc-400 sm:text-lg">
        {hero.description}
      </p>

      <div className="mb-10 flex flex-wrap gap-3">
        <a
          href="#projects"
          className="group inline-flex items-center gap-3 rounded-full bg-orange-500 px-6 py-3.5 text-sm font-semibold text-zinc-950 transition duration-300 hover:-translate-y-1 hover:bg-orange-400"
        >
          Explore selected work
          <ArrowUpRight
            size={18}
            className="transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
          />
        </a>

        <a
          href="#contact"
          className="inline-flex items-center gap-3 rounded-full border border-white/15 bg-white/[0.03] px-6 py-3.5 text-sm font-semibold text-white transition duration-300 hover:-translate-y-1 hover:border-orange-400/60 hover:bg-white/[0.07]"
        >
          Start a project
          <ArrowDownRight size={17} className="text-orange-400" />
        </a>
      </div>

      <div className="flex flex-wrap gap-x-5 gap-y-2 text-xs uppercase tracking-[0.18em] text-zinc-500">
        {hero.focus.map((item) => (
          <span key={item} className="flex items-center gap-2">
            <span className="h-1 w-1 rounded-full bg-orange-400" />
            {item}
          </span>
        ))}
      </div>
    </motion.div>
  );
}
