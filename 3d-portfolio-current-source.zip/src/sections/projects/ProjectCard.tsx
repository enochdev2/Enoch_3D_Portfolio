import { useReducedMotion, useMotionValue, useSpring, motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Badge } from "../../components/ui";
import type { Project } from "../../data/projects";

export default function ProjectCard({ project }: { project: Project }) {
  const shouldReduceMotion = useReducedMotion();
  const pointerX = useMotionValue(0);
  const pointerY = useMotionValue(0);
  const rotateX = useSpring(pointerY, {
    stiffness: 150,
    damping: 22,
    mass: 0.6,
  });
  const rotateY = useSpring(pointerX, {
    stiffness: 150,
    damping: 22,
    mass: 0.6,
  });

  function handlePointerMove(event: React.PointerEvent<HTMLElement>) {
    if (shouldReduceMotion || event.pointerType === "touch") return;

    const bounds = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width - 0.5;
    const y = (event.clientY - bounds.top) / bounds.height - 0.5;

    pointerX.set(x * 8);
    pointerY.set(y * -8);
  }

  function resetPointer() {
    pointerX.set(0);
    pointerY.set(0);
  }

  return (
    <Link
      to={`/projects/${project.slug}`}
      className="group block h-full [perspective:1200px]"
      aria-label={`View ${project.title} project`}
    >
      <motion.article
        initial={shouldReduceMotion ? false : { opacity: 0, y: 28 }}
        whileInView={shouldReduceMotion ? undefined : { opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        onPointerMove={handlePointerMove}
        onPointerLeave={resetPointer}
        style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
        whileHover={shouldReduceMotion ? undefined : { y: -7 }}
        transition={{ type: "spring", stiffness: 240, damping: 22 }}
        className="h-full overflow-hidden rounded-[1.75rem] border border-white/10 bg-gradient-to-br from-white/[0.07] to-white/[0.015] shadow-[0_18px_55px_rgba(0,0,0,0.2)] transition-colors duration-300 group-hover:border-orange-400/35"
      >
        <div className="relative aspect-[4/3] overflow-hidden bg-zinc-900">
          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-zinc-800 via-zinc-900 to-orange-950/30 text-[10px] uppercase tracking-[0.2em] text-zinc-500">
            Project preview
          </div>
          <img
            src={project.cover}
            alt={`${project.title} 3D project`}
            loading="lazy"
            className="relative h-full w-full object-contain p-3 transition duration-700 ease-out group-hover:scale-105"
            onError={(event) => {
              event.currentTarget.style.display = "none";
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/75 via-transparent to-transparent" />
          <span className="absolute bottom-4 left-4 rounded-full border border-white/15 bg-zinc-950/60 px-3 py-1.5 text-xs font-medium text-zinc-200 backdrop-blur-md">
            {project.category}
          </span>
          <span className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-zinc-950/50 text-white opacity-0 backdrop-blur-md transition duration-300 group-hover:opacity-100">
            <ArrowUpRight size={18} />
          </span>
        </div>

        <div className="space-y-4 p-5 sm:p-6" style={{ transform: "translateZ(24px)" }}>
          <div className="flex items-start justify-between gap-4">
            <h3 className="text-xl font-semibold tracking-tight text-white sm:text-2xl">
              {project.title}
            </h3>
            <ArrowUpRight
              size={19}
              className="mt-1 shrink-0 text-orange-400 transition duration-300 group-hover:-translate-y-1 group-hover:translate-x-1"
            />
          </div>

          <p className="line-clamp-3 text-sm leading-7 text-zinc-400">
            {project.description ?? project.overview}
          </p>

          <div className="flex flex-wrap gap-2">
            {project.tags.slice(0, 3).map((tag) => (
              <Badge key={tag} className="border-white/10 px-3 py-1 text-xs text-zinc-300">
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      </motion.article>
    </Link>
  );
}
