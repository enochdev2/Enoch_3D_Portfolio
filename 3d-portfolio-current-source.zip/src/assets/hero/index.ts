import character from "./character.png";
import enoch from "./enoch.png";
import Human from "./Human.png";
import walkCycleImage from "./walk cycle image.png";
import mangoJuice from "./mangoJuice.png";
import CatCartoon from "./Cat_Cartoon.png";
import clothSimulation from "./clothSimulation.png";
import nivea from "./nivea.png";
import hammer from "./hammer.png";
import earphone from "./earphone.png";
import headphoneProduct from "./headphone-product.png";


export { character, enoch, Human, walkCycleImage, mangoJuice, CatCartoon, clothSimulation, nivea, hammer, earphone, headphoneProduct };